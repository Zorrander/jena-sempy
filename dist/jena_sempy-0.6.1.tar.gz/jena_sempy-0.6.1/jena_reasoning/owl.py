class Knowledge:

    def __init__(self):
        pass
